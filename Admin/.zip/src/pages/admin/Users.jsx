const Users = () => {
    // TODO: yahan apna users list fetch/table wire karo (GET /api/admin/users jaisa endpoint)
    return (
        <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Users</h2>
            <div className="bg-white rounded-xl shadow-sm p-5 text-sm text-gray-500">
                Users list yahan aayegi — backend endpoint ready hote hi wire kar denge.
            </div>
        </div>
    );
};

export default Users;