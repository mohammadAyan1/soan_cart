import express from "express";
import upload from "../middleware/upload.js";
import { requiredAuth } from "../middleware/auth.middleware.js";

import {
    createProduct,
    updateProduct,
    getAllProduct,
    getProductById,
    getAllProductByVendor,
    deletProduct,
    deleteVariantImage,
    addVariantImage,
    getProductsByCategory,
    searchProducts, // 👈 NAYA IMPORT
} from "../controller/product.controller.js";

const productRouter = express.Router();

/* ============================
   Product
============================ */

// Create Product
productRouter.post(
    "/create",
    requiredAuth,
    upload.any(),
    createProduct
);

// Get All Products
productRouter.get(
    "/getall",
    getAllProduct
);

// 👇 naya route — category/subCategory se filtered products
// ⚠️ "/:id" route se PEHLE hona chahiye
productRouter.get(
    "/by-category",
    getProductsByCategory
);

// 👇 NAYA ROUTE — search bar ke liye
// ⚠️ "/:id" route se PEHLE hona chahiye
productRouter.get(
    "/search",
    searchProducts
);

// Get Product By Id
productRouter.get(
    "/:id",
    getProductById
);

// Vendor Products
productRouter.get(
    "/vendor/products",
    requiredAuth,
    getAllProductByVendor
);

// Update Product
productRouter.put(
    "/update/:id",
    requiredAuth,
    upload.any(),
    updateProduct
);

// Soft Delete / Restore
productRouter.put(
    "/delete/:id",
    requiredAuth,
    deletProduct
);

/* ============================
   Variant Images
============================ */

// Add Images
productRouter.post(
    "/variant/:variantId/images",
    requiredAuth,
    upload.any(),
    addVariantImage
);

// Delete Image
productRouter.delete(
    "/variant/:variantId/image/:imageId",
    requiredAuth,
    deleteVariantImage
);

export default productRouter;