import prisma from "../../config/prisma.js";

class AnalyticsService {

    /**
     * Track Analytics Event
     */
    async track({
        eventType,
        sessionId,
        payload,
        screen,
        source,
        eventAt
    }) {

        // Verify Session Exists
        const session = await prisma.userSession.findUnique({
            where: {
                sessionId
            }
        });

        if (!session) {
            throw new Error("Invalid session.");
        }

        const event = await prisma.analyticsEvent.create({
            data: {
                eventType,

                sessionId,

                userId: session.userId,

                guestId: session.guestId,

                screen,

                source,

                payload,

                eventAt: eventAt || new Date()
            }
        });

        return event;
    }

}

export default new AnalyticsService();