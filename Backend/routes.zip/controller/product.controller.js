import cloudinary from "../config/cloudinary.js";
import prisma from "../config/prisma.js";
import { uploadToCloudinary } from "../helper/cloudinaryUpload.js";

/**
 * ROUTE SETUP NOTE (multer):
 * ---------------------------------
 * Ye controller multer.any() expect karta hai, kyunki file field names
 * dynamic hain (har variant ke liye alag fieldname).
 *
 * router.post("/product", requiredAuth, upload.any(), createProduct);
 * router.put("/product/:id", requiredAuth, upload.any(), updateProduct);
 *
 * FIELD NAME CONVENTIONS (frontend se aise bhejna):
 * ---------------------------------
 * - "productImage"              -> Product ki apni image (single file)
 * - "variant_image_<variantId>" -> existing variant me naya image add karna ho
 * - "variant_image_new_<index>" -> naya variant add karte waqt uski images
 *
 * BODY (multipart/form-data, non-file fields as string/JSON string):
 * ---------------------------------
 * - productName, description, categoryId, subCategoryId, tags (JSON string array)
 * - deleteProductImage: "true" | "false"  -> product ki apni image sirf delete karni ho
 * - deleteImageIds: JSON string array of ProductImage.id -> variant images delete karne ke liye
 * - variants: JSON string array, har item:
 *     { id?, tempId?, description?, actualPrice, mrp, showMrp?, vendorMinPrice, stock?, tags?, attributes? }
 *     - "id" ho -> existing variant update
 *     - "id" na ho -> naya variant create, tempId use hoga image mapping ke liye (ya index se new_<i>)
 */

// ---------- Helper: cloudinary se multiple images upload ----------
const uploadMultiple = async (files) => {
    if (!files || files.length === 0) return [];
    return Promise.all(files.map((f) => uploadToCloudinary(f)));
};

// ---------- Helper: agar deleted image primary thi to next image ko primary banao ----------
const reassignPrimaryIfNeeded = async (tx, variantId, deletedImageWasPrimary) => {
    if (!deletedImageWasPrimary) return;

    const nextImage = await tx.productImage.findFirst({
        where: { productVariantId: variantId },
        orderBy: { createdAt: "asc" }
    });

    if (nextImage) {
        await tx.productImage.update({
            where: { id: nextImage.id },
            data: { isPrimary: true }
        });
    }
};

// ==================================================================
// CREATE PRODUCT
// ==================================================================
export const createProduct = async (req, res) => {
    try {
        const userId = req.user.id;
        const { role } = req.user;

        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const {
            productName,
            description,
            categoryId,
            subCategoryId,
            tags,
            variants
        } = req.body;





        if (!productName || !categoryId || !subCategoryId) {
            return res.status(400).json({
                success: false,
                message: "All fields are required"
            });
        }

        const files = req.files || [];

        // -----------------------------
        // Product Image Upload
        // -----------------------------
        const productImageFile = files.find(
            (f) => f.fieldname === "productImage"
        );


        let productImageResult = null;

        if (productImageFile) {
            productImageResult = await uploadToCloudinary(productImageFile);
        }



        // -----------------------------
        // Parse Variants
        // -----------------------------
        let parsedVariants = [];

        if (variants) {
            parsedVariants =
                typeof variants === "string"
                    ? JSON.parse(variants)
                    : variants;
        }





        // -----------------------------
        // Upload Variant Images BEFORE Transaction
        // -----------------------------

        const uploadedVariantImages = {};

        for (let i = 0; i < parsedVariants.length; i++) {

            const variant = parsedVariants[i];


            const tempKey = variant.tempId ?? `new_${i}`;




            const variantFiles = files.filter(
                (f) =>
                    f.fieldname === `variant_image_${tempKey}` ||
                    f.fieldname === `variant_image_new_${i}`
            );




            if (variantFiles.length > 0) {

                const uploaded = await uploadMultiple(variantFiles);

                uploadedVariantImages[tempKey] = uploaded;
            }
        }




        // -----------------------------
        // Database Transaction
        // -----------------------------

        const product = await prisma.$transaction(
            async (tx) => {

                const newProduct = await tx.product.create({
                    data: {
                        productName,
                        description,
                        userId,
                        categoryId: Number(categoryId),
                        subCategoryId: Number(subCategoryId),
                        tags: tags
                            ? typeof tags === "string"
                                ? JSON.parse(tags)
                                : tags
                            : null,
                        imageUrl: productImageResult?.secure_url ?? null,
                        imageId: productImageResult?.public_id ?? null
                    }
                });




                for (let i = 0; i < parsedVariants.length; i++) {

                    const v = parsedVariants[i];





                    const tempKey = v.tempId ?? `new_${i}`;




                    const newVariant = await tx.productVariant.create({
                        data: {
                            description: v.description ?? null,
                            actualPrice: Number(v.actualPrice),
                            mrp: Number(v.mrp),
                            showMrp:
                                v.showMrp === undefined
                                    ? true
                                    : v.showMrp,
                            isDefault: Boolean(v.isDefault),
                            vendorMinPrice: Number(v.vendorMinPrice),
                            stock: Number(v.stock ?? 0),
                            tags: v.tags ?? null,
                            attributes: v.attributes ?? null,
                            productId: newProduct.id
                        }
                    });




                    const uploaded = uploadedVariantImages[tempKey];




                    if (uploaded?.length) {

                        await tx.productImage.createMany({
                            data: uploaded.map((img, index) => ({
                                imageUrl: img.secure_url,
                                imageId: img.public_id,
                                isPrimary: index === 0,
                                productVariantId: newVariant.id
                            }))
                        });

                    }
                }

                return tx.product.findUnique({
                    where: {
                        id: newProduct.id
                    },
                    include: {
                        category: true,
                        subCategory: true,
                        variants: {
                            include: {
                                images: true
                            }
                        }
                    }
                });
            },
            {
                timeout: 20000,
                maxWait: 10000
            }
        );

        return res.status(201).json({
            success: true,
            message: "Product Created Successfully",
            product
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            success: false,
            message: error.message
        });

    }
};

// ==================================================================
// GET ALL PRODUCTS
// ==================================================================

export const getAllProduct = async (req, res) => {
    try {
        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        console.log('====================================');
        console.log("ASDFGHJKL");
        console.log('====================================');

        const whereCondition = {
            isDelete: false,
            variants: {
                some: {
                    isDelete: false,
                    isDefault: true
                }
            }
        };

        const [products, totalProducts] = await Promise.all([
            prisma.product.findMany({
                where: whereCondition,
                orderBy: {
                    createdAt: "desc"
                },
                skip,
                take: limit,

                select: {
                    id: true,
                    productName: true,
                    description: true,

                    variants: {
                        where: {
                            isDelete: false,
                            isDefault: true
                        },
                        take: 1,
                        select: {
                            id: true,
                            actualPrice: true,
                            mrp: true,
                            showMrp: true,

                            images: {
                                where: {
                                    isPrimary: true
                                },
                                take: 1,
                                select: {
                                    imageUrl: true
                                }
                            }
                        }
                    }
                }
            }),

            prisma.product.count({
                where: whereCondition
            })
        ]);

        return res.status(200).json({
            success: true,
            currentPage: page,
            perPage: limit,
            totalProducts,
            totalPages: Math.ceil(totalProducts / limit),
            hasNextPage: page < Math.ceil(totalProducts / limit),
            hasPreviousPage: page > 1,
            products
        });

    } catch (error) {


        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ==================================================================
// GET PRODUCT BY ID
// ==================================================================
export const getProductById = async (req, res) => {
    try {
        const productId = Number(req.params.id);

        if (!productId) {
            return res.status(400).json({
                success: false,
                message: "product id is required"
            });
        }

        const product = await prisma.product.findFirst({
            where: { id: productId, isDelete: false },
            include: {
                category: true,
                subCategory: true,
                user: { select: { id: true, fullName: true, email: true } },
                variants: {
                    where: { isDelete: false },
                    include: { images: true }
                }
            }
        });

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        return res.status(200).json({
            success: true,
            product
        });

    } catch (error) {

        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


// ==================================================================
// SEARCH PRODUCTS (debounced search se call hota hai, paginated)
// ==================================================================
export const searchProducts = async (req, res) => {
    try {
        const { q } = req.query;
        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        if (!q || !q.trim()) {
            return res.status(400).json({
                success: false,
                message: "Search query is required"
            });
        }

        // ⚠️ NOTE: MySQL me by default collation case-insensitive hoti hai,
        // isliye "mode: insensitive" nahi lagaya (ye sirf Postgres/Mongo me
        // support hota hai, MySQL me error dega)
        const whereCondition = {
            isDelete: false,
            productName: {
                contains: q.trim()
            },
            variants: {
                some: {
                    isDelete: false,
                    isDefault: true
                }
            }
        };

        const [products, totalProducts] = await Promise.all([
            prisma.product.findMany({
                where: whereCondition,
                orderBy: {
                    createdAt: "desc"
                },
                skip,
                take: limit,

                select: {
                    id: true,
                    productName: true,
                    description: true,

                    variants: {
                        where: {
                            isDelete: false,
                            isDefault: true
                        },
                        take: 1,
                        select: {
                            id: true,
                            actualPrice: true,
                            mrp: true,
                            showMrp: true,

                            images: {
                                where: {
                                    isPrimary: true
                                },
                                take: 1,
                                select: {
                                    imageUrl: true
                                }
                            }
                        }
                    }
                }
            }),

            prisma.product.count({
                where: whereCondition
            })
        ]);

        return res.status(200).json({
            success: true,
            currentPage: page,
            perPage: limit,
            totalProducts,
            totalPages: Math.ceil(totalProducts / limit),
            hasNextPage: page < Math.ceil(totalProducts / limit),
            hasPreviousPage: page > 1,
            products
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ==================================================================
// GET ALL PRODUCTS BY VENDOR
// ==================================================================
export const getAllProductByVendor = async (req, res) => {
    try {
        const { id: userId } = req.user;

        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const [products, totalProducts] = await Promise.all([
            prisma.product.findMany({
                where: { isDelete: false, userId },
                include: {
                    category: true,
                    subCategory: true,
                    user: { select: { id: true, fullName: true, email: true } },
                    variants: {
                        where: { isDelete: false },
                        include: { images: true }
                    }
                },
                orderBy: { createdAt: "desc" },
                skip,
                take: limit
            }),
            prisma.product.count({ where: { isDelete: false, userId } })
        ]);

        return res.status(200).json({
            success: true,
            currentPage: page,
            perPage: limit,
            totalProducts,
            totalPages: Math.ceil(totalProducts / limit),
            hasNextPage: page < Math.ceil(totalProducts / limit),
            hasPreviousPage: page > 1,
            products
        });

    } catch (error) {

        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ==================================================================
// UPDATE PRODUCT
// (Product image aur Variant images dono independently handle hote hain)
// ==================================================================

export const updateProduct = async (req, res) => {
    try {
        const { id: userId, role } = req.user;
        const productId = Number(req.params.id);

        if (!productId || isNaN(productId)) {
            return res.status(400).json({
                success: false,
                message: "product id is required"
            });
        }

        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const {
            productName,
            description,
            categoryId,
            subCategoryId,
            tags,
            deleteProductImage,
            deleteImageIds,
            variants
        } = req.body;

        if (!productName || !categoryId || !subCategoryId) {
            return res.status(400).json({
                success: false,
                message: "All fields are required"
            });
        }

        const existingProduct = await prisma.product.findUnique({
            where: { id: productId }
        });

        if (!existingProduct) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        if (role === "VENDOR" && existingProduct.userId !== userId) {
            return res.status(403).json({
                success: false,
                message: "You can update only your own product."
            });
        }

        const files = req.files || [];

        // ---------------- 1. PRODUCT KI APNI IMAGE ----------------
        // Ye sirf tab touch hogi jab productImage file aaye YA deleteProductImage true ho.
        // Variants ki images se iska koi lena dena nahi.
        const productImageFile = files.find((f) => f.fieldname === "productImage");

        let productImageData = {
            imageUrl: existingProduct.imageUrl,
            imageId: existingProduct.imageId
        };

        // Cloudinary calls yaha transaction ke BAHAR ho rahi hain (jaise create controller mein)
        if (productImageFile) {
            // Naya upload -> purani delete karo, nayi lagao
            if (existingProduct.imageId) {
                await cloudinary.uploader.destroy(existingProduct.imageId);
            }
            const uploaded = await uploadToCloudinary(productImageFile);
            productImageData = {
                imageUrl: uploaded.secure_url,
                imageId: uploaded.public_id
            };
        } else if (deleteProductImage === "true" || deleteProductImage === true) {
            // Sirf delete karni hai, naya upload nahi
            if (existingProduct.imageId) {
                await cloudinary.uploader.destroy(existingProduct.imageId);
            }
            productImageData = { imageUrl: null, imageId: null };
        }
        // Agar dono me se kuch nahi bheja -> product image bilkul untouched rahegi

        // ---------------- 2. VARIANTS PARSE ----------------
        let parsedVariants = [];
        if (variants) {
            parsedVariants = typeof variants === "string" ? JSON.parse(variants) : variants;
        }

        let parsedDeleteImageIds = [];
        if (deleteImageIds) {
            parsedDeleteImageIds = typeof deleteImageIds === "string" ? JSON.parse(deleteImageIds) : deleteImageIds;
            parsedDeleteImageIds = parsedDeleteImageIds.map(Number);
        }

        // ---------------- 3. VARIANT IMAGE DELETES — CLOUDINARY PEHLE (transaction ke bahar) ----------------
        // Security: sirf isi product ke variants ki images fetch/delete hongi
        let imagesToDelete = [];
        if (parsedDeleteImageIds.length > 0) {
            imagesToDelete = await prisma.productImage.findMany({
                where: {
                    id: { in: parsedDeleteImageIds },
                    variant: { productId }
                }
            });

            for (const img of imagesToDelete) {
                if (img.imageId) {
                    await cloudinary.uploader.destroy(img.imageId);
                }
            }
        }

        // ---------------- 4. VARIANT KI NAYI IMAGES — UPLOAD PEHLE (transaction ke bahar) ----------------
        // Key: existing variant ke liye uska id (number), naye variant ke liye tempKey (string)
        const uploadedVariantImages = {};

        for (let i = 0; i < parsedVariants.length; i++) {
            const v = parsedVariants[i];

            if (v.id) {
                // Existing variant ki nayi image (agar bheji ho)
                const newVariantFiles = files.filter(
                    (f) => f.fieldname === `variant_image_${v.id}`
                );

                if (newVariantFiles.length > 0) {
                    uploadedVariantImages[`existing_${v.id}`] = await uploadMultiple(newVariantFiles);
                }
            } else {
                // Naya variant ki image
                const tempKey = v.tempId ?? `new_${i}`;
                const variantFiles = files.filter(
                    (f) => f.fieldname === `variant_image_${tempKey}` || f.fieldname === `variant_image_new_${i}`
                );

                if (variantFiles.length > 0) {
                    uploadedVariantImages[tempKey] = await uploadMultiple(variantFiles);
                }
            }
        }

        // ---------------- 5. DATABASE TRANSACTION — sirf DB writes, koi external call nahi ----------------
        const skippedVariantIds = []; // ownership mismatch track karne ke liye

        const updatedProduct = await prisma.$transaction(async (tx) => {

            // ---- Product ke basic fields + apni image update ----
            const product = await tx.product.update({
                where: { id: productId },
                data: {
                    productName,
                    description,
                    categoryId: Number(categoryId),
                    subCategoryId: Number(subCategoryId),
                    isApprove: true,
                    tags: tags ? (typeof tags === "string" ? JSON.parse(tags) : tags) : null,
                    ...productImageData
                }
            });

            // ---- Variant images DB delete (Cloudinary already destroy ho chuka hai upar) ----
            for (const img of imagesToDelete) {
                await tx.productImage.delete({ where: { id: img.id } });
                await reassignPrimaryIfNeeded(tx, img.productVariantId, img.isPrimary);
            }

            // ---- VARIANTS UPDATE / CREATE + NAYI IMAGES ADD (already uploaded, sirf DB record banana hai) ----
            for (let i = 0; i < parsedVariants.length; i++) {
                const v = parsedVariants[i];

                if (v.id) {
                    // Existing variant belongs to this product? verify
                    const existingVariant = await tx.productVariant.findFirst({
                        where: { id: Number(v.id), productId }
                    });

                    if (!existingVariant) {
                        skippedVariantIds.push(v.id); // ownership mismatch, silently skip nahi — track karo
                        continue;
                    }

                    await tx.productVariant.update({
                        where: { id: existingVariant.id },
                        data: {
                            description: v.description ?? existingVariant.description,
                            actualPrice: v.actualPrice !== undefined ? Number(v.actualPrice) : existingVariant.actualPrice,
                            mrp: v.mrp !== undefined ? Number(v.mrp) : existingVariant.mrp,
                            showMrp: v.showMrp ?? existingVariant.showMrp,
                            vendorMinPrice: v.vendorMinPrice !== undefined ? Number(v.vendorMinPrice) : existingVariant.vendorMinPrice,
                            stock: v.stock !== undefined ? Number(v.stock) : existingVariant.stock,
                            tags: v.tags ?? existingVariant.tags,
                            attributes: v.attributes ?? existingVariant.attributes
                        }
                    });

                    // Is existing variant ke liye naya image add hua ho to (already uploaded hai upar)
                    const uploaded = uploadedVariantImages[`existing_${v.id}`];

                    if (uploaded?.length) {
                        const currentImageCount = await tx.productImage.count({
                            where: { productVariantId: existingVariant.id }
                        });

                        await tx.productImage.createMany({
                            data: uploaded.map((img, idx) => ({
                                imageUrl: img.secure_url,
                                imageId: img.public_id,
                                isPrimary: currentImageCount === 0 && idx === 0,
                                productVariantId: existingVariant.id
                            }))
                        });
                    }

                } else {
                    // Naya variant create ho raha hai
                    const tempKey = v.tempId ?? `new_${i}`;

                    const newVariant = await tx.productVariant.create({
                        data: {
                            description: v.description ?? null,
                            actualPrice: Number(v.actualPrice),
                            mrp: Number(v.mrp),
                            showMrp: v.showMrp ?? true,
                            vendorMinPrice: Number(v.vendorMinPrice),
                            stock: Number(v.stock ?? 0),
                            tags: v.tags ?? null,
                            attributes: v.attributes ?? null,
                            productId
                        }
                    });

                    const uploaded = uploadedVariantImages[tempKey];

                    if (uploaded?.length) {
                        await tx.productImage.createMany({
                            data: uploaded.map((img, idx) => ({
                                imageUrl: img.secure_url,
                                imageId: img.public_id,
                                isPrimary: idx === 0,
                                productVariantId: newVariant.id
                            }))
                        });
                    }
                }
            }

            return tx.product.findUnique({
                where: { id: productId },
                include: {
                    category: true,
                    subCategory: true,
                    variants: {
                        where: { isDelete: false },
                        include: { images: true }
                    }
                }
            });
        }, {
            timeout: 20000,
            maxWait: 10000
        });

        return res.status(200).json({
            success: true,
            message: "Product Updated Successfully",
            product: updatedProduct,
            ...(skippedVariantIds.length > 0 && {
                warning: `In variant IDs ka ownership match nahi hua, skip kar diya: ${skippedVariantIds.join(", ")}`
            })
        });

    } catch (error) {

        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ==================================================================
// DELETE PRODUCT (soft delete, variants bhi saath me soft delete)
// ==================================================================
export const deletProduct = async (req, res) => {
    try {
        const { id: userId, role } = req.user;
        const productId = Number(req.params.id);

        if (!productId) {
            return res.status(400).json({
                success: false,
                message: "product id is required"
            });
        }

        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const product = await prisma.product.findUnique({
            where: { id: productId }
        });

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        if (role === "VENDOR" && product.userId !== userId) {
            return res.status(403).json({
                success: false,
                message: "You can update only your own product."
            });
        }

        const toggledStatus = !product.isDelete;

        await prisma.$transaction(async (tx) => {
            await tx.product.update({
                where: { id: productId },
                data: { isDelete: toggledStatus }
            });

            // Variants ko bhi product ke saath hi toggle karo (consistent state)
            await tx.productVariant.updateMany({
                where: { productId },
                data: { isDelete: toggledStatus }
            });
        });

        return res.status(200).json({
            success: true,
            message: toggledStatus ? "Product deleted successfully" : "Product restored successfully"
        });

    } catch (error) {

        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ==================================================================
// STANDALONE: DELETE A SINGLE VARIANT IMAGE
// (update flow ke bahar bhi quick delete karna ho to ye use karo)
// ==================================================================
export const deleteVariantImage = async (req, res) => {
    try {
        const { id: userId, role } = req.user;

        const variantId = Number(req.params.variantId);
        const imageId = Number(req.params.imageId);

        if (!variantId || !imageId) {
            return res.status(400).json({
                success: false,
                message: "Variant Id and Image Id are required."
            });
        }

        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority."
            });
        }

        const variant = await prisma.productVariant.findUnique({
            where: { id: variantId },
            include: { product: true }
        });

        if (!variant) {
            return res.status(404).json({
                success: false,
                message: "Variant not found."
            });
        }

        if (role === "VENDOR" && variant.product.userId !== userId) {
            return res.status(403).json({
                success: false,
                message: "You can delete only your own product images."
            });
        }

        const image = await prisma.productImage.findFirst({
            where: { id: imageId, productVariantId: variantId }
        });

        if (!image) {
            return res.status(404).json({
                success: false,
                message: "Image not found."
            });
        }

        await prisma.$transaction(async (tx) => {
            if (image.imageId) {
                await cloudinary.uploader.destroy(image.imageId);
            }
            await tx.productImage.delete({ where: { id: image.id } });
            await reassignPrimaryIfNeeded(tx, variantId, image.isPrimary);
        });

        const images = await prisma.productImage.findMany({
            where: { productVariantId: variantId },
            orderBy: { createdAt: "asc" }
        });

        return res.status(200).json({
            success: true,
            message: "Image deleted successfully.",
            images
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ==================================================================
// STANDALONE: ADD IMAGE(S) TO AN EXISTING VARIANT
// (update flow ke bahar bhi quick add karna ho to ye use karo)
// ==================================================================
export const addVariantImage = async (req, res) => {
    try {
        const { id: userId, role } = req.user;
        const variantId = Number(req.params.variantId);

        if (!variantId) {
            return res.status(400).json({
                success: false,
                message: "Variant id is required."
            });
        }

        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority."
            });
        }

        const variant = await prisma.productVariant.findUnique({
            where: { id: variantId },
            include: { product: true }
        });

        if (!variant) {
            return res.status(404).json({
                success: false,
                message: "Variant not found."
            });
        }

        if (role === "VENDOR" && variant.product.userId !== userId) {
            return res.status(403).json({
                success: false,
                message: "You can add images only to your own product."
            });
        }

        const files = req.files || [];
        if (files.length === 0) {
            return res.status(400).json({
                success: false,
                message: "At least one image is required."
            });
        }

        const uploaded = await uploadMultiple(files);

        const currentImageCount = await prisma.productImage.count({
            where: { productVariantId: variantId }
        });

        await prisma.productImage.createMany({
            data: uploaded.map((img, idx) => ({
                imageUrl: img.secure_url,
                imageId: img.public_id,
                isPrimary: currentImageCount === 0 && idx === 0,
                productVariantId: variantId
            }))
        });

        const images = await prisma.productImage.findMany({
            where: { productVariantId: variantId },
            orderBy: { createdAt: "asc" }
        });

        return res.status(200).json({
            success: true,
            message: "Image(s) added successfully.",
            images
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};



export const getProductsByCategory = async (req, res) => {
    try {
        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const { categoryId, subCategoryId } = req.query;

        if (!categoryId && !subCategoryId) {
            return res.status(400).json({
                success: false,
                message: "categoryId ya subCategoryId me se ek to dena hi padega"
            });
        }

        const whereCondition = {
            isDelete: false,
            variants: {
                some: {
                    isDelete: false,
                    isDefault: true
                }
            },
            ...(categoryId && { categoryId: Number(categoryId) }),
            ...(subCategoryId && { subCategoryId: Number(subCategoryId) })
        };

        const [products, totalProducts] = await Promise.all([
            prisma.product.findMany({
                where: whereCondition,
                orderBy: {
                    createdAt: "desc"
                },
                skip,
                take: limit,

                select: {
                    id: true,
                    productName: true,
                    description: true,

                    variants: {
                        where: {
                            isDelete: false,
                            isDefault: true
                        },
                        take: 1,
                        select: {
                            id: true,
                            actualPrice: true,
                            mrp: true,
                            showMrp: true,

                            images: {
                                where: {
                                    isPrimary: true
                                },
                                take: 1,
                                select: {
                                    imageUrl: true
                                }
                            }
                        }
                    }
                }
            }),

            prisma.product.count({
                where: whereCondition
            })
        ]);

        return res.status(200).json({
            success: true,
            currentPage: page,
            perPage: limit,
            totalProducts,
            totalPages: Math.ceil(totalProducts / limit),
            hasNextPage: page < Math.ceil(totalProducts / limit),
            hasPreviousPage: page > 1,
            products
        });

    } catch (error) {

        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};