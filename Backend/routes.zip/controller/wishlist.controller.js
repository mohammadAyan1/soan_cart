// 📁 Save at: controller/wishlist.controller.js

import prisma from "../config/prisma.js";
import { getOrCreateWishlist } from "../utils/wishlist.helper.js";

// ================== ADD TO WISHLIST ==================
// Body: { productId, variantId }
// Cart ki tarah hi - guest bhi add kar sakta hai, x-guest-id header se track hota hai
export const addToWishlist = async (req, res) => {
    try {
        const { productId, variantId } = req.body;

        if (!productId || !variantId) {
            return res.status(400).json({
                success: false,
                message: "productId aur variantId dono required hain",
            });
        }

        // Variant valid hai aur isi product ka hai, ye verify karo
        const variant = await prisma.productVariant.findFirst({
            where: {
                id: Number(variantId),
                productId: Number(productId),
                isDelete: false,
            },
            include: { product: true },
        });

        if (!variant) {
            return res.status(404).json({
                success: false,
                message: "Product variant nahi mila",
            });
        }

        const { wishlist, guestId, isNewGuest } = await getOrCreateWishlist(req);

        // Ye variant already wishlist me hai kya, check karo
        const existingItem = await prisma.wishlistItem.findUnique({
            where: {
                wishlistId_variantId: {
                    wishlistId: wishlist.id,
                    variantId: variant.id,
                },
            },
        });

        if (existingItem) {
            return res.status(200).json({
                success: true,
                message: "Ye product pehle se hi wishlist me hai",
                wishlistItem: existingItem,
                ...(isNewGuest && { guestId }),
            });
        }

        const wishlistItem = await prisma.wishlistItem.create({
            data: {
                wishlistId: wishlist.id,
                productId: Number(productId),
                variantId: variant.id,
                // Snapshot - product jis vendor ka hai
                vendorId: variant.product.userId,
            },
        });

        return res.status(201).json({
            success: true,
            message: "Product wishlist me add ho gaya",
            wishlistItem,
            ...(isNewGuest && { guestId }),
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
};

// ================== GET WISHLIST ==================
export const getWishlist = async (req, res) => {
    try {
        const { wishlist, guestId, isNewGuest } = await getOrCreateWishlist(req);

        const items = await prisma.wishlistItem.findMany({
            where: { wishlistId: wishlist.id },
            include: {
                product: {
                    select: { id: true, productName: true, description: true },
                },
                variant: {
                    select: {
                        id: true,
                        description: true,
                        actualPrice: true,
                        mrp: true,
                        showMrp: true,
                        stock: true,
                        attributes: true,
                        images: {
                            where: { isPrimary: true },
                            select: { imageUrl: true },
                            take: 1,
                        },
                    },
                },
                vendor: { select: { id: true, fullName: true } },
            },
            orderBy: { createdAt: "desc" },
        });

        const formattedItems = items.map((item) => ({
            wishlistItemId: item.id,

            productId: item.product.id,
            productName: item.product.productName,
            productDescription: item.product.description,

            variantId: item.variant.id,
            variantDescription: item.variant.description,
            variantAttributes: item.variant.attributes,
            inStock: item.variant.stock > 0,

            productImage:
                item.variant.images.length > 0 ? item.variant.images[0].imageUrl : null,

            actualPrice: Number(item.variant.actualPrice),
            mrp: Number(item.variant.mrp),
            showMrp: item.variant.showMrp,

            vendor: item.vendor,
            addedAt: item.createdAt,
        }));

        return res.status(200).json({
            success: true,
            items: formattedItems,
            totalItems: formattedItems.length,
            ...(isNewGuest && { guestId }),
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
};

// ================== REMOVE ONE ITEM (by variantId) ==================
export const removeWishlistItem = async (req, res) => {
    try {
        const variantId = Number(req.params.variantId);
        const { wishlist } = await getOrCreateWishlist(req);

        const item = await prisma.wishlistItem.findUnique({
            where: {
                wishlistId_variantId: { wishlistId: wishlist.id, variantId },
            },
        });

        if (!item) {
            return res.status(404).json({
                success: false,
                message: "Ye product wishlist me nahi mila",
            });
        }

        await prisma.wishlistItem.delete({ where: { id: item.id } });

        return res.status(200).json({
            success: true,
            message: "Product wishlist se hata diya gaya",
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
};

// ================== CLEAR ENTIRE WISHLIST (ek hi baar me) ==================
export const clearWishlist = async (req, res) => {
    try {
        const { wishlist } = await getOrCreateWishlist(req);

        await prisma.wishlistItem.deleteMany({ where: { wishlistId: wishlist.id } });

        return res.status(200).json({
            success: true,
            message: "Pura wishlist empty kar diya gaya",
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
};

// ==================================================================
// MERGE HELPER - login ke time automatically call hoga (auth.controller.js se)
// Guest wishlist ke items user ke wishlist me shift ho jayenge.
// Agar same variant dono me hai to guest wala duplicate delete ho jayega
// (quantity jaisi cheez wishlist me nahi hoti, isliye cart se yahi farak hai)
// ==================================================================
export const mergeGuestWishlistWithUser = async (userId, guestId) => {
    return await prisma.$transaction(async (tx) => {
        const guestWishlist = await tx.wishlist.findUnique({
            where: { guestId },
            include: { items: true },
        });

        // Guest id header me thi, lekin uska wishlist DB me nahi mila
        if (!guestWishlist) {
            return false;
        }

        let userWishlist = await tx.wishlist.findUnique({ where: { userId } });

        // User ka pehle se koi wishlist nahi hai -> guest wishlist ko hi
        // user wishlist bana do (fast path)
        if (!userWishlist) {
            await tx.wishlist.update({
                where: { id: guestWishlist.id },
                data: { userId, guestId: null },
            });
            return true;
        }

        // Dono wishlist maujood hain -> item by item merge karo
        for (const item of guestWishlist.items) {
            const existingUserItem = await tx.wishlistItem.findUnique({
                where: {
                    wishlistId_variantId: {
                        wishlistId: userWishlist.id,
                        variantId: item.variantId,
                    },
                },
            });

            if (existingUserItem) {
                // Ye variant already user ke wishlist me hai -> guest wala duplicate hata do
                await tx.wishlistItem.delete({ where: { id: item.id } });
            } else {
                // Naya variant -> seedha shift kar do
                await tx.wishlistItem.update({
                    where: { id: item.id },
                    data: { wishlistId: userWishlist.id },
                });
            }
        }

        // Ab guest wishlist khali ho chuka hai, delete kar do
        await tx.wishlist.delete({ where: { id: guestWishlist.id } });
        return true;
    });
};

// ================== MANUAL MERGE ENDPOINT (POST /api/wishlist/merge) ==================
// Cart wale mergeGuestCart jaisa hi - agar frontend chahe to alag se bhi call kar sakta hai,
// lekin normally ye login ke time hi automatic ho jayega
export const mergeGuestWishlist = async (req, res) => {
    try {
        const userId = req.user?.id;
        const guestId = req.headers["x-guest-id"];

        if (!userId) {
            return res.status(401).json({
                success: false,
                message: "User authenticated nahi hai, pehle login karo",
            });
        }

        if (!guestId) {
            const userWishlist = await prisma.wishlist.upsert({
                where: { userId },
                update: {},
                create: { userId },
                include: { items: true },
            });

            return res.status(200).json({
                success: true,
                message: "Guest id nahi mili, user ka wishlist bheja gaya",
                wishlist: userWishlist,
            });
        }

        const merged = await mergeGuestWishlistWithUser(userId, guestId);

        const userWishlist = await prisma.wishlist.findUnique({
            where: { userId },
            include: { items: { include: { product: true, variant: true } } },
        });

        return res.status(200).json({
            success: true,
            message: merged
                ? "Guest wishlist user wishlist me merge ho gaya"
                : "Koi guest wishlist nahi mila, user wishlist bheja gaya",
            wishlist: userWishlist,
        });
    } catch (error) {
        console.error("Error in mergeGuestWishlist:", error);
        return res.status(500).json({
            success: false,
            message: "Wishlist merge karte waqt error aaya",
            error: error.message,
        });
    }
};

// ==================================================================
// ADMIN: kis user ne apne wishlist me kya kya add kiya hai - sab dikhao
// (GET /api/wishlist/admin/all)
// ==================================================================
export const getAllWishlistsAdmin = async (req, res) => {
    try {
        const { role } = req.user;
        if (role !== "ADMIN") {
            return res.status(403).json({ success: false, message: "You don't have authority" });
        }

        const wishlists = await prisma.wishlist.findMany({
            where: { userId: { not: null } },
            include: {
                user: { select: { id: true, fullName: true, email: true, phone: true } },
                items: {
                    include: {
                        product: { select: { id: true, productName: true, imageUrl: true } },
                        variant: true,
                        vendor: { select: { id: true, fullName: true } },
                    },
                    orderBy: { createdAt: "desc" },
                },
            },
            orderBy: { updatedAt: "desc" },
        });

        return res.status(200).json({ success: true, data: wishlists });
    } catch (error) {
        console.error("getAllWishlistsAdmin error:", error);
        return res.status(500).json({ success: false, message: "Wishlists fetch karne me error aaya" });
    }
};

// ==================================================================
// ADMIN: sabse jyada wishlist me add hua product + sabse jyada
// wishlist hua vendor (GET /api/wishlist/admin/stats)
// ==================================================================
export const getWishlistStatsAdmin = async (req, res) => {
    try {
        const { role } = req.user;
        if (role !== "ADMIN") {
            return res.status(403).json({ success: false, message: "You don't have authority" });
        }

        // ---------------- Product-wise: kaunsa product sabse zyada wishlist hua ----------------
        const productGrouped = await prisma.wishlistItem.groupBy({
            by: ["productId"],
            _count: { id: true },
            orderBy: { _count: { id: "desc" } },
        });

        const productIds = productGrouped.map((p) => p.productId);
        const products = await prisma.product.findMany({
            where: { id: { in: productIds } },
            select: { id: true, productName: true, imageUrl: true, userId: true },
        });

        const topProducts = productGrouped.map((p) => ({
            product: products.find((pr) => pr.id === p.productId),
            totalWishlistCount: p._count.id,
        }));

        // ---------------- Vendor-wise: kis vendor ka product sabse zyada wishlist hua ----------------
        const vendorGrouped = await prisma.wishlistItem.groupBy({
            by: ["vendorId"],
            _count: { id: true },
            orderBy: { _count: { id: "desc" } },
        });

        const vendorIds = vendorGrouped.map((v) => v.vendorId);
        const vendors = await prisma.user.findMany({
            where: { id: { in: vendorIds } },
            select: { id: true, fullName: true, email: true },
        });

        const topVendors = vendorGrouped.map((v) => ({
            vendor: vendors.find((u) => u.id === v.vendorId),
            totalWishlistCount: v._count.id,
        }));

        return res.status(200).json({
            success: true,
            topProducts, // sabse zyada wishlist hue products, descending order me
            topVendors, // sabse zyada wishlist hue vendors, descending order me
        });
    } catch (error) {
        console.error("getWishlistStatsAdmin error:", error);
        return res.status(500).json({ success: false, message: "Wishlist stats fetch karne me error aaya" });
    }
};