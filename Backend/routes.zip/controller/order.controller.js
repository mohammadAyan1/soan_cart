import { prisma, DeliveryStatus, PaymentStatus, OrderType } from "../config/prisma.js";

// ------------------------------------------------------------------
// Helper: unique order number generator
// ------------------------------------------------------------------
function generateOrderNumber() {
    const ts = Date.now().toString(36).toUpperCase();
    const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
    return `ORD-${ts}-${rand}`;
}

// Jo status "terminal"/return-flow hai unko normal update se change nahi
// karne dena (return flow ke apne dedicated endpoints hai)
const RETURN_FLOW_STATUSES = [
    DeliveryStatus.RETURN_REQUESTED,
    DeliveryStatus.RETURN_ACCEPTED,
    DeliveryStatus.RETURN_REJECTED,
    DeliveryStatus.RETURNED,
];

// ==================================================================
// 1) CHECKOUT FROM CART  (POST /api/orders/checkout/cart)
//    - Cart ke saare items ka ek hi Order banega, har item ek
//      alag OrderItem banega (apne vendor ke saath)
//    - Success hone ke baad: cart empty, stock decrease
// ==================================================================
export const checkoutFromCart = async (req, res) => {
    try {
        const userId = req.user.id;
        const { fullName, phone, addressLine, city, state, pincode, orderType } = req.body;

        if (!fullName || !phone || !addressLine || !city || !state || !pincode) {
            return res.status(400).json({ success: false, message: "Address ki saari fields required hai" });
        }
        if (!orderType || !Object.values(OrderType).includes(orderType)) {
            return res.status(400).json({ success: false, message: "orderType ONLINE ya COD hona chahiye" });
        }

        // User ka cart uske items ke saath nikalo
        const cart = await prisma.cart.findUnique({
            where: { userId },
            include: {
                items: {
                    include: {
                        product: true,
                        variant: true,
                    },
                },
            },
        });

        if (!cart || cart.items.length === 0) {
            return res.status(400).json({ success: false, message: "Cart khali hai" });
        }

        // Stock validate karo pehle hi (transaction ke bahar quick check)
        for (const item of cart.items) {
            if (item.variant.isDelete) {
                return res.status(400).json({ success: false, message: `Ek product available nahi hai (variant #${item.variantId})` });
            }
            if (item.variant.stock < item.quantity) {
                return res.status(400).json({
                    success: false,
                    message: `${item.product.productName} ka stock kam hai. Available: ${item.variant.stock}`,
                });
            }
        }

        const totalAmount = cart.items.reduce(
            (sum, item) => sum + Number(item.variant.actualPrice) * item.quantity,
            0
        );

        const order = await prisma.$transaction(async (tx) => {
            // Order create karo
            const newOrder = await tx.order.create({
                data: {
                    orderNumber: generateOrderNumber(),
                    userId,
                    totalAmount,
                    paymentStatus: PaymentStatus.PENDING,
                    orderType,
                    fullName,
                    phone,
                    addressLine,
                    city,
                    state,
                    pincode,
                },
            });

            // Har cart item ke liye OrderItem banao + stock kam karo
            for (const item of cart.items) {
                const orderItem = await tx.orderItem.create({
                    data: {
                        orderId: newOrder.id,
                        productId: item.productId,
                        variantId: item.variantId,
                        vendorId: item.product.userId, // product jiska hai wahi vendor
                        quantity: item.quantity,
                        price: item.variant.actualPrice,
                        deliveryStatus: DeliveryStatus.PENDING,
                    },
                });

                // Status history ki first entry
                await tx.orderItemStatusHistory.create({
                    data: {
                        orderItemId: orderItem.id,
                        status: DeliveryStatus.PENDING,
                        note: "Order placed",
                    },
                });

                // Stock decrease
                await tx.productVariant.update({
                    where: { id: item.variantId },
                    data: { stock: { decrement: item.quantity } },
                });
            }

            // Cart empty karo
            await tx.cartItem.deleteMany({ where: { cartId: cart.id } });

            return newOrder;
        });

        const fullOrder = await prisma.order.findUnique({
            where: { id: order.id },
            include: { items: { include: { product: true, variant: true } } },
        });

        return res.status(201).json({ success: true, message: "Order successfully placed", data: fullOrder });
    } catch (error) {
        console.error("checkoutFromCart error:", error);
        return res.status(500).json({ success: false, message: `Order create karne me error aaya ${error?.message}` });
    }
};

// ==================================================================
// 2) DIRECT SINGLE PRODUCT CHECKOUT (POST /api/orders/checkout/direct)
//    - Cart involve nahi hota, seedha ek productId+variantId se order
// ==================================================================
export const checkoutSingleProduct = async (req, res) => {
    try {
        const userId = req.user.id;
        const {
            productId,
            variantId,
            quantity,
            fullName,
            phone,
            addressLine,
            city,
            state,
            pincode,
            orderType,
        } = req.body;

        if (!productId || !variantId) {
            return res.status(400).json({ success: false, message: "productId aur variantId required hai" });
        }
        if (!fullName || !phone || !addressLine || !city || !state || !pincode) {
            return res.status(400).json({ success: false, message: "Address ki saari fields required hai" });
        }
        if (!orderType || !Object.values(OrderType).includes(orderType)) {
            return res.status(400).json({ success: false, message: "orderType ONLINE ya COD hona chahiye" });
        }

        const qty = Number(quantity) > 0 ? Number(quantity) : 1;

        const variant = await prisma.productVariant.findUnique({
            where: { id: Number(variantId) },
            include: { product: true },
        });

        if (!variant || variant.isDelete || variant.productId !== Number(productId)) {
            return res.status(404).json({ success: false, message: "Product variant nahi mila" });
        }
        if (variant.stock < qty) {
            return res.status(400).json({ success: false, message: `Stock kam hai. Available: ${variant.stock}` });
        }

        const totalAmount = Number(variant.actualPrice) * qty;

        const order = await prisma.$transaction(async (tx) => {
            const newOrder = await tx.order.create({
                data: {
                    orderNumber: generateOrderNumber(),
                    userId,
                    totalAmount,
                    paymentStatus: PaymentStatus.PENDING,
                    orderType,
                    fullName,
                    phone,
                    addressLine,
                    city,
                    state,
                    pincode,
                },
            });

            const orderItem = await tx.orderItem.create({
                data: {
                    orderId: newOrder.id,
                    productId: variant.productId,
                    variantId: variant.id,
                    vendorId: variant.product.userId,
                    quantity: qty,
                    price: variant.actualPrice,
                    deliveryStatus: DeliveryStatus.PENDING,
                },
            });

            await tx.orderItemStatusHistory.create({
                data: {
                    orderItemId: orderItem.id,
                    status: DeliveryStatus.PENDING,
                    note: "Order placed",
                },
            });

            await tx.productVariant.update({
                where: { id: variant.id },
                data: { stock: { decrement: qty } },
            });

            return newOrder;
        });

        const fullOrder = await prisma.order.findUnique({
            where: { id: order.id },
            include: { items: { include: { product: true, variant: true } } },
        });

        return res.status(201).json({ success: true, message: "Order successfully placed", data: fullOrder });
    } catch (error) {
        console.error("checkoutSingleProduct error:", error);
        return res.status(500).json({ success: false, message: "Order create karne me error aaya" });
    }
};

// ==================================================================
// 3) USER: apne saare orders dekhna (GET /api/orders/my-orders)
// ==================================================================
export const getMyOrders = async (req, res) => {
    try {
        const userId = req.user.id;

        const orders = await prisma.order.findMany({
            where: { userId, isDelete: false },
            include: {
                items: {
                    include: {
                        product: { select: { id: true, productName: true, imageUrl: true } },
                        variant: {
                            include: {
                                images: {
                                    where: { isPrimary: true },
                                    take: 1
                                }
                            }
                        },
                        vendor: { select: { id: true, fullName: true } },
                        statusHistory: { orderBy: { changedAt: "asc" } },
                    },
                },
            },
            orderBy: { createdAt: "desc" },
        });

        return res.status(200).json({ success: true, data: orders });
    } catch (error) {
        console.error("getMyOrders error:", error);
        return res.status(500).json({ success: false, message: "Orders fetch karne me error aaya" });
    }
};

// Single order detail (GET /api/orders/my-orders/:orderId)
export const getMyOrderById = async (req, res) => {
    try {
        const userId = req.user.id;
        const orderId = Number(req.params.orderId);

        const order = await prisma.order.findFirst({
            where: { userId, isDelete: false },
            include: {
                items: {
                    include: {
                        product: { select: { id: true, productName: true, imageUrl: true } },
                        variant: {
                            include: {
                                images: {
                                    where: { isPrimary: true },
                                    take: 1
                                }
                            }
                        },
                        vendor: { select: { id: true, fullName: true } },
                        statusHistory: { orderBy: { changedAt: "asc" } },
                    },
                },
            },
        });

        if (!order) {
            return res.status(404).json({ success: false, message: "Order nahi mila" });
        }

        return res.status(200).json({ success: true, data: order });
    } catch (error) {
        console.error("getMyOrderById error:", error);
        return res.status(500).json({ success: false, message: "Order fetch karne me error aaya" });
    }
};

// ==================================================================
// 4) USER: return request daalna (PATCH /api/orders/items/:orderItemId/return-request)
// ==================================================================
export const requestReturn = async (req, res) => {
    try {
        const userId = req.user.id;
        const orderItemId = Number(req.params.orderItemId);
        const { note } = req.body;

        const orderItem = await prisma.orderItem.findUnique({
            where: { id: orderItemId },
            include: { order: true },
        });

        if (!orderItem || orderItem.order.userId !== userId) {
            return res.status(404).json({ success: false, message: "Order item nahi mila" });
        }
        if (orderItem.deliveryStatus !== DeliveryStatus.DELIVERED) {
            return res.status(400).json({ success: false, message: "Sirf delivered product ka hi return request ho sakta hai" });
        }

        const updated = await prisma.$transaction(async (tx) => {
            const item = await tx.orderItem.update({
                where: { id: orderItemId },
                data: { deliveryStatus: DeliveryStatus.RETURN_REQUESTED },
            });
            await tx.orderItemStatusHistory.create({
                data: {
                    orderItemId,
                    status: DeliveryStatus.RETURN_REQUESTED,
                    note: note || "Return requested by user",
                },
            });
            return item;
        });

        return res.status(200).json({ success: true, message: "Return request submit ho gayi", data: updated });
    } catch (error) {
        console.error("requestReturn error:", error);
        return res.status(500).json({ success: false, message: "Return request me error aaya" });
    }
};

// ==================================================================
// 5) VENDOR/ADMIN: return request accept/reject
//    (PATCH /api/orders/items/:orderItemId/return-response)
//    body: { action: "ACCEPT" | "REJECT", note }
// ==================================================================
export const respondToReturn = async (req, res) => {
    try {

        const { role } = req.user;
        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const { action, note } = req.body;
        const orderItemId = Number(req.params.orderItemId);

        if (!["ACCEPT", "REJECT"].includes(action)) {
            return res.status(400).json({ success: false, message: "action ACCEPT ya REJECT hona chahiye" });
        }

        const orderItem = await prisma.orderItem.findUnique({ where: { id: orderItemId } });
        if (!orderItem) {
            return res.status(404).json({ success: false, message: "Order item nahi mila" });
        }

        // Vendor sirf apne hi item ka respond kar sakta hai
        if (req.user.role === "VENDOR" && orderItem.vendorId !== req.user.id) {
            return res.status(403).json({ success: false, message: "Ye order item aapka nahi hai" });
        }
        if (orderItem.deliveryStatus !== DeliveryStatus.RETURN_REQUESTED) {
            return res.status(400).json({ success: false, message: "Is item par koi pending return request nahi hai" });
        }

        const newStatus = action === "ACCEPT" ? DeliveryStatus.RETURN_ACCEPTED : DeliveryStatus.RETURN_REJECTED;

        const updated = await prisma.$transaction(async (tx) => {
            const item = await tx.orderItem.update({
                where: { id: orderItemId },
                data: { deliveryStatus: newStatus },
            });
            await tx.orderItemStatusHistory.create({
                data: { orderItemId, status: newStatus, note: note || `Return ${action.toLowerCase()}ed` },
            });
            return item;
        });

        return res.status(200).json({ success: true, message: `Return ${action.toLowerCase()}ed`, data: updated });
    } catch (error) {
        console.error("respondToReturn error:", error);
        return res.status(500).json({ success: false, message: "Return response me error aaya" });
    }
};

// Return finally warehouse me confirm hone par (PATCH /api/orders/items/:orderItemId/return-confirm)
// Admin/vendor - jab return accepted product physically wapas aa jaye
export const confirmReturned = async (req, res) => {
    try {

        const { role } = req.user;
        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const orderItemId = Number(req.params.orderItemId);
        const { note } = req.body;

        const orderItem = await prisma.orderItem.findUnique({ where: { id: orderItemId } });
        if (!orderItem) {
            return res.status(404).json({ success: false, message: "Order item nahi mila" });
        }
        if (req.user.role === "VENDOR" && orderItem.vendorId !== req.user.id) {
            return res.status(403).json({ success: false, message: "Ye order item aapka nahi hai" });
        }
        if (orderItem.deliveryStatus !== DeliveryStatus.RETURN_ACCEPTED) {
            return res.status(400).json({ success: false, message: "Return pehle accept hona chahiye" });
        }

        const updated = await prisma.$transaction(async (tx) => {
            const item = await tx.orderItem.update({
                where: { id: orderItemId },
                data: { deliveryStatus: DeliveryStatus.RETURNED },
            });
            await tx.orderItemStatusHistory.create({
                data: { orderItemId, status: DeliveryStatus.RETURNED, note: note || "Product returned & received back" },
            });
            // stock wapas add karna ho toh yaha kar sakte ho:
            await tx.productVariant.update({
                where: { id: orderItem.variantId },
                data: { stock: { increment: orderItem.quantity } },
            });
            return item;
        });

        return res.status(200).json({ success: true, message: "Return confirm ho gaya", data: updated });
    } catch (error) {
        console.error("confirmReturned error:", error);
        return res.status(500).json({ success: false, message: "Return confirm karne me error aaya" });
    }
};

// ==================================================================
// 6) VENDOR/ADMIN: delivery status update + expected delivery date
//    (PATCH /api/orders/items/:orderItemId/status)
//    body: { status, note, expectedDeliveryDate }
// ==================================================================
export const updateOrderItemStatus = async (req, res) => {
    try {

        const { role } = req.user;
        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const orderItemId = Number(req.params.orderItemId);
        const { status, note, expectedDeliveryDate } = req.body;



        if (status && !Object.values(DeliveryStatus).includes(status)) {
            return res.status(400).json({ success: false, message: "Invalid status" });
        }
        // Return flow ke status yaha se set nahi karne dena - unke apne endpoints hai
        if (status && RETURN_FLOW_STATUSES.includes(status)) {
            return res.status(400).json({
                success: false,
                message: "Return se related status yaha se change nahi hote, return endpoints use karo",
            });
        }

        const orderItem = await prisma.orderItem.findUnique({ where: { id: orderItemId } });
        if (!orderItem) {
            return res.status(404).json({ success: false, message: "Order item nahi mila" });
        }

        // Vendor sirf apne hi product ka status/expected date update kar sakta hai
        if (req.user.role === "VENDOR" && orderItem.vendorId !== req.user.id) {
            return res.status(403).json({ success: false, message: "Ye order item aapka nahi hai" });
        }

        const dataToUpdate = {};
        if (status) dataToUpdate.deliveryStatus = status;
        if (expectedDeliveryDate) dataToUpdate.expectedDeliveryDate = new Date(expectedDeliveryDate);

        if (Object.keys(dataToUpdate).length === 0) {
            return res.status(400).json({ success: false, message: "status ya expectedDeliveryDate me se kam se kam ek dena hoga" });
        }

        const updated = await prisma.$transaction(async (tx) => {
            const item = await tx.orderItem.update({
                where: { id: orderItemId },
                data: dataToUpdate,
            });

            // History sirf tab log hogi jab status actually change ho
            if (status) {
                await tx.orderItemStatusHistory.create({
                    data: { orderItemId, status, note: note || null },
                });
            }

            return item;
        });

        return res.status(200).json({ success: true, message: "Order item update ho gaya", data: updated });
    } catch (error) {
        console.error("updateOrderItemStatus error:", error);
        return res.status(500).json({ success: false, message: "Status update karne me error aaya" });
    }
};

// ==================================================================
// 7) ADMIN: saare orders (GET /api/orders/admin/all)
// ==================================================================
export const getAllOrdersAdmin = async (req, res) => {
    try {

        const { role } = req.user;
        if (role !== "ADMIN") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 20;

        const [orders, total] = await Promise.all([
            prisma.order.findMany({
                where: { isDelete: false },
                include: {
                    user: { select: { id: true, fullName: true, email: true, phone: true } },
                    items: {
                        include: {
                            product: { select: { id: true, productName: true } },
                            variant: true,
                            vendor: { select: { id: true, fullName: true } },
                            statusHistory: { orderBy: { changedAt: "asc" } },
                        },
                    },
                },
                orderBy: { createdAt: "desc" },
                skip: (page - 1) * limit,
                take: limit,
            }),
            prisma.order.count({ where: { isDelete: false } }),
        ]);

        return res.status(200).json({
            success: true,
            data: orders,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
        });
    } catch (error) {
        console.error("getAllOrdersAdmin error:", error);
        return res.status(500).json({ success: false, message: "Orders fetch karne me error aaya" });
    }
};

// ==================================================================
// 8) ADMIN: vendor-wise sales stats (GET /api/orders/admin/vendor-stats)
//    - kis vendor ke kitne product bike, kitna revenue, kaun kaun user ne khareeda
// ==================================================================
export const getVendorSalesStatsAdmin = async (req, res) => {
    try {


        const { role } = req.user;
        if (role !== "ADMIN") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }
        // Vendor-wise total quantity sold + revenue
        const vendorGrouped = await prisma.orderItem.groupBy({
            by: ["vendorId"],
            _sum: { quantity: true, price: true },
            _count: { id: true },
        });

        const vendorIds = vendorGrouped.map((v) => v.vendorId);
        const vendors = await prisma.user.findMany({
            where: { id: { in: vendorIds } },
            select: { id: true, fullName: true, email: true, phone: true },
        });

        const result = await Promise.all(
            vendorGrouped.map(async (v) => {
                const vendorInfo = vendors.find((u) => u.id === v.vendorId);

                // Vendor ke products kis kis user ne khareeda
                const buyers = await prisma.orderItem.findMany({
                    where: { vendorId: v.vendorId },
                    include: {
                        order: { include: { user: { select: { id: true, fullName: true, email: true } } } },
                        product: { select: { id: true, productName: true } },
                    },
                });

                // Unique user list nikalna
                const uniqueBuyersMap = new Map();
                buyers.forEach((item) => {
                    uniqueBuyersMap.set(item.order.user.id, item.order.user);
                });

                return {
                    vendor: vendorInfo,
                    totalItemsSold: v._sum.quantity || 0,
                    totalOrderItems: v._count.id,
                    totalRevenue: v._sum.price ? Number(v._sum.price) : 0,
                    buyers: Array.from(uniqueBuyersMap.values()),
                    soldDetails: buyers.map((b) => ({
                        product: b.product.productName,
                        quantity: b.quantity,
                        price: b.price,
                        buyer: b.order.user.fullName,
                        deliveryStatus: b.deliveryStatus,
                    })),
                };
            })
        );

        return res.status(200).json({ success: true, data: result });
    } catch (error) {
        console.error("getVendorSalesStatsAdmin error:", error);
        return res.status(500).json({ success: false, message: "Vendor stats fetch karne me error aaya" });
    }
};

// ==================================================================
// 9) VENDOR: apne hi order items dekhna (GET /api/orders/vendor/my-orders)
//    - sirf user ka naam aur address dikhega, poori profile nahi
// ==================================================================
export const getVendorOrders = async (req, res) => {
    try {

        const { role } = req.user;
        if (role !== "ADMIN" && role !== "VENDOR") {
            return res.status(403).json({
                success: false,
                message: "You don't have authority"
            });
        }

        const vendorId = req.user.id;

        const orderItems = await prisma.orderItem.findMany({
            where: { vendorId },
            include: {
                product: { select: { id: true, productName: true, imageUrl: true } },
                variant: true,
                statusHistory: { orderBy: { changedAt: "asc" } },
                order: {
                    select: {
                        id: true,
                        orderNumber: true,
                        orderType: true,
                        paymentStatus: true,
                        createdAt: true,
                        // Sirf naam aur address - vendor ko user ka email/phone nahi chahiye
                        fullName: true,
                        phone: true,
                        addressLine: true,
                        city: true,
                        state: true,
                        pincode: true,
                    },
                },
            },
            orderBy: { createdAt: "desc" },
        });

        return res.status(200).json({ success: true, data: orderItems });
    } catch (error) {
        console.error("getVendorOrders error:", error);
        return res.status(500).json({ success: false, message: "Orders fetch karne me error aaya" });
    }
};
