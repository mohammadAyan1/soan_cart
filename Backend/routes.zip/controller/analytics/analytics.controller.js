import analyticsService from "../../services/analytics/analytics.service.js";

export const trackEvent = async (req, res) => {

    try {

        const {
            eventType,
            sessionId,
            userId,
            guestId,
            payload
        } = req.body;

        if (!eventType) {
            return res.status(400).json({
                success: false,
                message: "eventType is required."
            });
        }

        if (!sessionId) {
            return res.status(400).json({
                success: false,
                message: "sessionId is required."
            });
        }

        const event = await analyticsService.track({
            eventType,
            sessionId,
            userId,
            guestId,
            payload
        });

        return res.status(201).json({
            success: true,
            message: "Analytics event tracked successfully.",
            data: event
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            success: false,
            message: error.message
        });

    }

};