import prisma from "../config/prisma.js";
import { getOrCreateCart } from "../utils/cart.helper.js";

// ================== ADD TO CART ==================
// Body: { productId, variantId, quantity (optional, default 1) }
// Agar ye variant cart mein already hai -> quantity increment ho jayegi
// Agar nahi hai -> naya row banega
// Different variant (same product ke) hamesha alag row banate hain (unique constraint ki wajah se)
export const addToCart = async (req, res) => {
    try {
        const { productId, variantId, quantity } = req.body;

        if (!productId || !variantId) {
            return res.status(400).json({
                success: false,
                message: "productId aur variantId dono required hain"
            });
        }

        const qty = quantity ? Number(quantity) : 1;

        if (qty <= 0) {
            return res.status(400).json({
                success: false,
                message: "quantity 1 ya usse zyada honi chahiye"
            });
        }

        // Variant valid hai aur isi product ka hai, ye verify karo
        const variant = await prisma.productVariant.findFirst({
            where: {
                id: Number(variantId),
                productId: Number(productId),
                isDelete: false
            }
        });

        if (!variant) {
            return res.status(404).json({
                success: false,
                message: "Product variant nahi mila"
            });
        }

        if (variant.stock < qty) {
            return res.status(400).json({
                success: false,
                message: `Sirf ${variant.stock} stock available hai`
            });
        }

        const { cart, guestId, isNewGuest } = await getOrCreateCart(req);

        // Ye variant is cart mein already hai kya, check karo
        const existingItem = await prisma.cartItem.findUnique({
            where: {
                cartId_variantId: {
                    cartId: cart.id,
                    variantId: variant.id
                }
            }
        });

        let cartItem;

        if (existingItem) {
            const newQty = existingItem.quantity + qty;

            if (newQty > variant.stock) {
                return res.status(400).json({
                    success: false,
                    message: `Cart mein total quantity stock (${variant.stock}) se zyada nahi ho sakti`
                });
            }

            cartItem = await prisma.cartItem.update({
                where: { id: existingItem.id },
                data: { quantity: newQty }
            });
        } else {
            cartItem = await prisma.cartItem.create({
                data: {
                    cartId: cart.id,
                    productId: Number(productId),
                    variantId: variant.id,
                    quantity: qty
                }
            });
        }

        return res.status(200).json({
            success: true,
            message: "Product cart mein add ho gaya",
            cartItem,
            // Guest ka naya UUID hai to frontend ko batao — isko localStorage mein save karke
            // agli har cart request mein "x-guest-id" header ke through bhejna hai
            ...(isNewGuest && { guestId })
        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ================== GET CART ==================
export const getCart = async (req, res) => {
    try {
        const { cart, guestId, isNewGuest } = await getOrCreateCart(req);
        

        const items = await prisma.cartItem.findMany({
            where: {
                cartId: cart.id
            },
            include: {
                product: {
                    select: {
                        id: true,
                        productName: true,
                        description: true,
                    }
                },
                variant: {
                    select: {
                        id: true,
                        description: true,
                        actualPrice: true,
                        mrp: true,
                        showMrp: true,
                        attributes: true,
                        images: {
                            where: {
                                isPrimary: true
                            },
                            select: {
                                imageUrl: true
                            },
                            take: 1
                        }
                    }
                }
            },
            orderBy: {
                createdAt: "desc"
            }
        });




        const formattedItems = items.map((item) => ({
            cartItemId: item.id,

            productId: item.product.id,
            productName: item.product.productName,
            productDescription: item.product.description,

            variantId: item.variant.id,
            variantDescription: item.variant.description,
            variantAttributes: item.variant.attributes,

            productImage:
                item.variant.images.length > 0
                    ? item.variant.images[0].imageUrl
                    : null,

            quantity: item.quantity,

            actualPrice: Number(item.variant.actualPrice),
            mrp: Number(item.variant.mrp),
            showMrp: item.variant.showMrp,

            totalPrice:
                Number(item.variant.actualPrice) * item.quantity
        }));

        const cartTotal = formattedItems.reduce((sum, i) => sum + i.totalPrice, 0);



        const totalAmount = formattedItems.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
        const totalMrpAmount = formattedItems.reduce(
            (sum, item) => sum + (item.mrp || 0) * item.quantity,
            0
        );
        const totalSavings = totalMrpAmount - totalAmount;


        return res.status(200).json({
            success: true,
            items: formattedItems,
            totalItems: formattedItems.length,
            cartTotal,
            ...(isNewGuest && { guestId }),
            totalSavings

        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ================== INCREASE QUANTITY (by 1) ==================
export const increaseQuantity = async (req, res) => {
    try {
        const variantId = Number(req.params.variantId);
        const { cart } = await getOrCreateCart(req);

        const item = await prisma.cartItem.findUnique({
            where: {
                cartId_variantId: { cartId: cart.id, variantId }
            },
            include: { variant: true }
        });

        if (!item) {
            return res.status(404).json({
                success: false,
                message: "Ye product cart mein nahi mila"
            });
        }

        if (item.quantity + 1 > item.variant.stock) {
            return res.status(400).json({
                success: false,
                message: `Sirf ${item.variant.stock} stock available hai`
            });
        }

        const updated = await prisma.cartItem.update({
            where: { id: item.id },
            data: { quantity: item.quantity + 1 }
        });

        return res.status(200).json({
            success: true,
            message: "Quantity 1 se badha di",
            cartItem: updated
        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ================== DECREASE QUANTITY (by 1) ==================
// Agar quantity 1 se 0 pe aati hai -> row hi delete ho jayegi (poora product cart se hat jayega)
export const decreaseQuantity = async (req, res) => {
    try {
        const variantId = Number(req.params.variantId);
        const { cart } = await getOrCreateCart(req);

        const item = await prisma.cartItem.findUnique({
            where: {
                cartId_variantId: { cartId: cart.id, variantId }
            }
        });

        if (!item) {
            return res.status(404).json({
                success: false,
                message: "Ye product cart mein nahi mila"
            });
        }

        if (item.quantity <= 1) {
            await prisma.cartItem.delete({ where: { id: item.id } });

            return res.status(200).json({
                success: true,
                message: "Quantity 0 ho gayi, product cart se remove ho gaya",
                removed: true
            });
        }

        const updated = await prisma.cartItem.update({
            where: { id: item.id },
            data: { quantity: item.quantity - 1 }
        });

        return res.status(200).json({
            success: true,
            message: "Quantity 1 se kam ki",
            cartItem: updated
        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ================== REMOVE ITEM DIRECTLY (chahe quantity kitni bhi ho) ==================
// User agar 10 quantity add kiya hai aur ek hi click mein poora product hatana chahta hai
export const removeCartItem = async (req, res) => {
    try {
        const variantId = Number(req.params.variantId);
        const { cart } = await getOrCreateCart(req);

        const item = await prisma.cartItem.findUnique({
            where: {
                cartId_variantId: { cartId: cart.id, variantId }
            }
        });

        if (!item) {
            return res.status(404).json({
                success: false,
                message: "Ye product cart mein nahi mila"
            });
        }

        await prisma.cartItem.delete({ where: { id: item.id } });

        return res.status(200).json({
            success: true,
            message: "Product cart se hata diya gaya (chahe kitni bhi quantity thi)"
        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// ================== CLEAR ENTIRE CART ==================
export const clearCart = async (req, res) => {
    try {
        const { cart } = await getOrCreateCart(req);

        await prisma.cartItem.deleteMany({
            where: { cartId: cart.id }
        });

        return res.status(200).json({
            success: true,
            message: "Pura cart empty kar diya gaya"
        });

    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

//================== merg guest item with actual user ===========
export const mergeGuestCart = async (req, res) => {
    try {
        const userId = req.user?.id;
        const guestId = req.headers["x-guest-id"];

        if (!userId) {
            return res.status(401).json({
                success: false,
                message: "User authenticated nahi hai, pehle login karo",
            });
        }

        // CASE A: guest id hi nahi bheji -> seedha user cart bhej do
        if (!guestId) {
            const userCart = await prisma.cart.upsert({
                where: { userId },
                update: {},
                create: { userId },
                include: { items: true },
            });

            return res.status(200).json({
                success: true,
                message: "Guest id nahi mili, user ka cart bheja gaya",
                cart: userCart,
            });
        }

        const result = await prisma.$transaction(async (tx) => {
            const guestCart = await tx.cart.findUnique({
                where: { guestId },
                include: { items: true },
            });

            let userCart = await tx.cart.findUnique({
                where: { userId },
            });

            // CASE B: guest cart mila hi nahi
            if (!guestCart) {
                if (!userCart) {
                    userCart = await tx.cart.create({ data: { userId } });
                }

                const items = await tx.cartItem.findMany({
                    where: { cartId: userCart.id },
                });

                return { cart: userCart, items, merged: false };
            }

            // CASE C: guest cart hai, user ka cart abhi tak nahi bana
            if (!userCart) {
                userCart = await tx.cart.update({
                    where: { id: guestCart.id },
                    data: {
                        userId,
                        guestId: null,
                    },
                });

                const items = await tx.cartItem.findMany({
                    where: { cartId: userCart.id },
                });

                return { cart: userCart, items, merged: true };
            }

            // CASE D: dono cart maujood hain -> merge karo
            for (const item of guestCart.items) {
                const existingUserItem = await tx.cartItem.findUnique({
                    where: {
                        cartId_variantId: {
                            cartId: userCart.id,
                            variantId: item.variantId,
                        },
                    },
                });

                if (existingUserItem) {
                    // Same variant pehle se user cart me hai -> quantity badhao
                    await tx.cartItem.update({
                        where: { id: existingUserItem.id },
                        data: {
                            quantity: existingUserItem.quantity + item.quantity,
                        },
                    });

                    // guest wala item ab redundant, delete kar do
                    await tx.cartItem.delete({ where: { id: item.id } });
                } else {
                    // User cart me ye variant nahi tha -> item ko shift kar do
                    await tx.cartItem.update({
                        where: { id: item.id },
                        data: { cartId: userCart.id },
                    });
                }
            }

            // Ab guest cart khali ho chuka hai -> delete kar do
            await tx.cart.delete({ where: { id: guestCart.id } });

            const finalItems = await tx.cartItem.findMany({
                where: { cartId: userCart.id },
            });

            return { cart: userCart, items: finalItems, merged: true };
        });

        return res.status(200).json({
            success: true,
            message: result.merged
                ? "Guest cart user cart me merge ho gaya"
                : "Koi guest cart nahi mila, user cart bheja gaya",
            cart: result.cart,
            items: result.items,
        });
    } catch (error) {
        console.error("Error in mergeGuestCart:", error);
        return res.status(500).json({
            success: false,
            message: "Cart merge karte waqt error aaya",
            error: error.message,
        });
    }
};

